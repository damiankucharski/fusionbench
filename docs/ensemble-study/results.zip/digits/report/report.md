# fusionbench characterization report

## digits

| method         |   macro_f1 |
|:---------------|-----------:|
| stacking_lr    |     0.9799 |
| simple_average |     0.9753 |
| best_single    |     0.9751 |
| okapi          |     0.973  |

## Per-scenario winners

| scenario   | primary_metric   |   best_test_score | best_method   |   best_regret | expected_winners   | as_expected   |
|:-----------|:-----------------|------------------:|:--------------|--------------:|:-------------------|:--------------|
| digits     | macro_f1         |            0.9799 | stacking_lr   |           nan |                    |               |
