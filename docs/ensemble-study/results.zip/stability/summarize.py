"""Rebuild tables and the crossed-seed figure next to the raw CSV files."""
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import t

root = Path(__file__).resolve().parent
runs = pd.concat([pd.read_csv(root / d / "restarts.csv").assign(protocol=d)
                  for d in ("confirmation", "all_fit", "long_search", "long_archive")])
runs.groupby(["protocol", "domain", "policy"])[[
    "accuracy", "accuracy_regret", "macro_f1", "nodes", "total_fitness_calls", "total_search_seconds"
]].mean().to_csv(root / "policy_means.csv")
search = pd.read_csv(root / "confirmation" / "search.csv")
iid = search.query('domain == "iid" and method == "fit_champion"')
cells = iid.groupby(["scenario", "data_seed"]).macro_f1
dispersion = pd.concat([cells.std().groupby("scenario").mean().rename("avg_within_data_sd"),
                        cells.mean().groupby("scenario").std().rename("sd_of_data_means")], axis=1)
dispersion.to_csv(root / "seed_dispersions.csv")
measures = [
    ("Selection on independent labels", ("confirmation","restart_holdout_best"), ("confirmation","restart_fit_champion")),
    ("Selection vs fitting all labels", ("confirmation","restart_holdout_best"), ("all_fit","restart_all_fit_champion")),
    ("Four starts vs one final population", ("confirmation","restart_holdout_best"), ("long_search","restart_holdout_best")),
    ("Four starts vs one archived trajectory", ("confirmation","restart_holdout_best"), ("long_archive","restart_holdout_best")),
]
contrasts = []
for domain, group in runs.groupby("domain"):
    matrix = group.groupby(["data_seed","protocol","policy"]).macro_f1.mean().unstack(["protocol","policy"])
    for label, method, reference in measures:
        differences = matrix[method] - matrix[reference]
        half_width = differences.sem() * t.ppf(.975, len(differences)-1)
        contrasts.append(dict(domain=domain, contrast=label, n=len(differences), delta=100*differences.mean(),
                              lower=100*(differences.mean()-half_width), upper=100*(differences.mean()+half_width)))
contrasts = pd.DataFrame(contrasts)
contrasts.to_csv(root / "paired_intervals.csv", index=False)
fig, ax = plt.subplots(figsize=(9, 3.8), layout="constrained")
for domain, offset, color in (("iid", -.11, "#006d70"), ("shift", .11, "#c15e19")):
    rows = contrasts.query("domain == @domain")
    y = np.arange(len(rows)) + offset
    ax.errorbar(rows.delta, y, xerr=[rows.delta-rows.lower, rows.upper-rows.delta], fmt="o",
                capsize=3, label="Same distribution" if domain=="iid" else "Shifted inputs", color=color)
ax.axvline(0, color="black", lw=.8)
ax.set_yticks(np.arange(len(measures)), [k for k, _, _ in measures])
ax.invert_yaxis()
ax.set_xlabel("Paired macro-F1 difference (percentage points, 95% interval)")
ax.set_title("Search and selection in four controlled FusionBench scenarios", loc="left")
ax.spines[["top","right","left"]].set_visible(False)
ax.legend(loc="lower center", bbox_to_anchor=(.5,-.46), ncol=2, frameon=False)
fig.savefig(root / "search_contrasts.png", dpi=175)
